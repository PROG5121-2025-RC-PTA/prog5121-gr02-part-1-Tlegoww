import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testMessageLengthSuccess() {
        String msgText = "Hi Mike, can you join us for dinner tonight";
        assertTrue(msgText.length() <= 250, "Message ready to send.");
    }

    @Test
    public void testMessageLengthFailure() {
        String longMessage = "A".repeat(260);
        int overBy = longMessage.length() - 250;
        assertTrue(longMessage.length() > 250,
                "Message exceeds 250 characters by " + overBy + ", please reduce size.");
    }

    @Test
    public void testRecipientPhoneNumberSuccess() {
        Message m = new Message("1234567890", "+27718693002", "Hello");
        assertEquals(12, m.checkRecipientCell(), "Cell phone number successfully captured.");
    }

    @Test
    public void testRecipientPhoneNumberFailure() {
        Message m = new Message("1234567890", "08575975889", "Hello");
        assertEquals(-1, m.checkRecipientCell(), "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
    }

    @Test
    public void testMessageIDLength() {
        String id = "1234567890";
        Message m = new Message(id, "+27718693002", "Hello");
        assertTrue(m.checkMessageID(), "Message ID generated: " + m.getMessageID());
    }

    @Test
    public void testCreateMessageHash() {
        Message m = new Message("0034567890", "+27718693002", "Hi Mike, can you join us for dinner tonight");
        String expectedHash = "00:1:HITONIGHT";
        assertEquals(expectedHash, m.getMessageHash());
    }

    @Test
    public void testSendMessageOption() {
        // Simulate Send message (normally done through GUI, but here we simulate)
        Message m = new Message("1234567890", "+27718693002", "Hello Mike");
        String userChoice = "send"; // Simulated user selection
        assertEquals("send", userChoice, "Message successfully sent.");
    }

    @Test
    public void testDisregardMessageOption() {
        Message m = new Message("1234567890", "+27718693002", "Hello Mike");
        String userChoice = "disregard";
        assertEquals("disregard", userChoice, "Message disregarded.");
    }

    @Test
    public void testStoreMessageOption() {
        Message m = new Message("1234567890", "+27718693002", "Hello Mike");
        String userChoice = "store";
        assertEquals("store", userChoice, "Message successfully stored.");
    }
}


