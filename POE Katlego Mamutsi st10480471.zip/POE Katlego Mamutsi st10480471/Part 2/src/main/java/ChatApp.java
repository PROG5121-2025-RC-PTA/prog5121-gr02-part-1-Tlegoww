import javax.swing.*;
import java.util.*;

public class ChatApp {
    static Map<String, Login> users = new HashMap<>();
    static Login currentUser;

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        while (true) {
            String[] options = {"Register", "Login", "Exit"};
            int choice = JOptionPane.showOptionDialog(
                    null, "==== ChatApp Menu ====",
                    "ChatApp",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);

            switch (choice) {
                case 0 -> register();
                case 1 -> login();
                case 2 -> {
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                        System.exit(0);
                }
default -> JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }

    private static void register() {
        String username = JOptionPane.showInputDialog("Enter Username:");
        if (username == null) return;

        if (users.containsKey(username)) {
            JOptionPane.showMessageDialog(null, "Username already taken. Please choose another.");
            return;
        }

        String password = JOptionPane.showInputDialog("Enter Password:");
        if (password == null) return;

        String cell = JOptionPane.showInputDialog("Enter Cell Phone (+27 format):");
        if (cell == null) return;

        String first = JOptionPane.showInputDialog("Enter First Name:");
        if (first == null) return;

        String last = JOptionPane.showInputDialog("Enter Last Name:");
        if (last == null) return;

        Login newUser = new Login(username, password, cell, first, last);
        String msg = newUser.registerUser();
        JOptionPane.showMessageDialog(null, msg);

        if (msg.equals("User registered successfully!")) {
        users.put(username, newUser);
        }
    }

    private static void login() {
        String user = JOptionPane.showInputDialog("Enter Username:");
        if (user == null) return;

        String pass = JOptionPane.showInputDialog("Enter Password:");
        if (pass == null) return;

        Login loginUser = users.get(user);
        if (loginUser == null) {
        JOptionPane.showMessageDialog(null, "No such user. Please register first.");
        return;
        }

        if (loginUser.loginUser(user, pass)) {
        currentUser = loginUser;
        JOptionPane.showMessageDialog(null, currentUser.returnLoginStatus());
        startChat();
        } else {
            JOptionPane.showMessageDialog(null, loginUser.returnLoginStatus());
    }
}

    private static void startChat() {
        Chat chat = new Chat(currentUser, users);
        chat.run();
    }
}
