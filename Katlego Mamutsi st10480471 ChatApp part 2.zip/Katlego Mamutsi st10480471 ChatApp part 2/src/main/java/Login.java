public class Login {
    private final String username;
    private final String password;
    private final String cellPhone;
    private final String firstName;
    private final String lastName;
    private boolean isLoggedIn = false;

    public Login(String username, String password, String cellPhone, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.cellPhone = cellPhone;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        return password.matches("^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$");
    }

    public boolean checkCellPhoneNumber() {
        return cellPhone.matches("^\\+27\\d{9}$");
    }

    public String registerUser() {
        if (!checkUserName())
        return "Username must contain an underscore and be no more than 5 characters.";
        if (!checkPasswordComplexity())
        return "Password must contain uppercase, digit, special char, and be 8+ chars.";
        if (!checkCellPhoneNumber())
        return "Cell number must start with +27 and be 12 characters.";
        return "User registered successfully!";
    }

    public boolean loginUser(String inputUsername, String inputPassword) {
        isLoggedIn = this.username.equals(inputUsername) && this.password.equals(inputPassword);
        return isLoggedIn;
    }

    public String returnLoginStatus() {
        if (isLoggedIn)
        return "Welcome " + firstName + " " + lastName + "! Ready to chat.";
        return "Username or password incorrect.";
    }

    public String getUsername() {
        return username;
    }

    public String getCellPhone() {
        return cellPhone;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
}
