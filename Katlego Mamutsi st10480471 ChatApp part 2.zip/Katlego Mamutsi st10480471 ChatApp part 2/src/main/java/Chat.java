import javax.swing.*;
import java.util.*;

public class Chat {
    private final Map<String, Login> users;
    private int messageLimit = 0;
    private int messagesSent = 0;

    public Chat(Login user, Map<String, Login> users) {
        this.users = users;
    }

    public void run() {
        String limitStr = JOptionPane.showInputDialog("Enter the number of messages you wish to send:");
        if (limitStr != null) {
            try {
            messageLimit = Integer.parseInt(limitStr);
    }       catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Invalid number. Setting limit to 0.");
        messageLimit = 0;
}
      } else {
            JOptionPane.showMessageDialog(null, "No input provided. Setting limit to 0.");
            messageLimit = 0;
    }

        while (true) {
            String menu = """
                          ===== QuickChat Menu =====
                          1) Send Messages
                          2) Show recently sent messages (Coming soon)
                          3) Quit
                          Enter your option (1, 2, or 3):""";
            String option = JOptionPane.showInputDialog(menu);
        if (option == null) continue;

        switch(option) {
            case "1" -> sendMessage();
            case "2" -> {
                String allMessages = Message.printMessages();
                if (allMessages.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No messages have been sent yet.");
                }   else {
                    JOptionPane.showMessageDialog(null, allMessages);
                }       }
            case "3" -> {
                String total = "Total number of messages sent: " + Message.returnTotalMessages();
                JOptionPane.showMessageDialog(null, total);
                return;
                }
            default -> JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }

    private void sendMessage() {
        if (messagesSent >= messageLimit) {
            JOptionPane.showMessageDialog(null, "Message limit reached. You cannot send more messages.");
            return;
        }

        String recipientUsername = JOptionPane.showInputDialog("Enter recipient username:");
        if (recipientUsername == null || !users.containsKey(recipientUsername)) {
            JOptionPane.showMessageDialog(null, "User not found.");
            return;
        }

        Login recipientLogin = users.get(recipientUsername);
        String recipientCell = recipientLogin.getCellPhone();

        String messageText = JOptionPane.showInputDialog("Enter message (max 50 characters):");
        if (messageText == null) return;
        if (messageText.length() >= 50) {
            JOptionPane.showMessageDialog(null, "Please enter a message of less than 50 characters.");
            return;
        }

        long idLong = Math.abs(new java.util.Random().nextLong()) % 10000000000L;
        String messageID = String.format("%010d", idLong);

        Message msg = new Message(messageID, recipientCell, messageText);

        if (!msg.checkMessageID()) {
            JOptionPane.showMessageDialog(null, "Invalid Message ID generated.");
            return;
        }
        if (msg.checkRecipientCell() == -1) {
            JOptionPane.showMessageDialog(null, "Invalid recipient cell number.");
                return;
        }

        String action = msg.SentMessage();
        switch (action) {
            case "send" -> {
                Message.sentMessages.add(msg);
                messagesSent++;
                JOptionPane.showMessageDialog(null,
                        """
                        Message sent!
                        
                        MessageID: """ + msg.getMessageID() + "\n" +
                                        "Message Hash: " + msg.getMessageHash() + "\n" +
                                                "Recipient: " + msg.getRecipient() + "\n" +
                                                        "Message: " + msg.getMessageText());
            }
            case "store" -> {
                msg.storeMessage();
                Message.sentMessages.add(msg);
                messagesSent++;
                JOptionPane.showMessageDialog(null,
                        """
                        Message stored to send later!
                        
                        MessageID: """ + msg.getMessageID() + "\n" +
                                        "Message Hash: " + msg.getMessageHash() + "\n" +
                                                "Recipient: " + msg.getRecipient() + "\n" +
                                                        "Message: " + msg.getMessageText());
            }
            case "disregard" -> JOptionPane.showMessageDialog(null, "Message disregarded.");
            default -> {
            }
        }
    }
}