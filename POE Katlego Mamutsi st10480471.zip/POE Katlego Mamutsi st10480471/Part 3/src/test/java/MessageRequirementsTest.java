import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;


public class MessageRequirementsTest {

    @BeforeEach
    public void setUp() {
        Message.populateTestData();
    }

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        String[] actualMessages = new String[Message.sentMessages.size()];
        for (int i = 0; i < Message.sentMessages.size(); i++) {
            actualMessages[i] = Message.sentMessages.get(i).getMessageText();
        }

        boolean foundMessage1 = false;
        boolean foundMessage4 = false;
        
        for (String msg : actualMessages) {
            if (msg.equals("Did you get the cake?")) {
                foundMessage1 = true;
            }
            if (msg.equals("It is dinner time!")) {
                foundMessage4 = true;
            }
        }

        assertTrue(foundMessage1, "Expected message 'Did you get the cake?' found in sent messages");
        assertTrue(foundMessage4, "Expected message 'It is dinner time!' found in sent messages");
        
        String[] expectedMessages = {"Did you get the cake?", "It is dinner time!"};
        assertTrue(foundMessage1 && foundMessage4, 
                "The Messages array contains the expected test data: " + 
                String.join(", ", expectedMessages));
    }

    @Test
    public void testDisplayLongestMessage() {
        String longestMessage = "";
        
        for (Message m : Message.sentMessages) {
            if (m.getMessageText().length() > longestMessage.length()) {
                longestMessage = m.getMessageText();
            }
        }
        
        for (Message m : Message.storedMessages) {
            if (m.getMessageText().length() > longestMessage.length()) {
                longestMessage = m.getMessageText();
            }
        }
        
        for (Message m : Message.disregardedMessages) {
            if (m.getMessageText().length() > longestMessage.length()) {
                longestMessage = m.getMessageText();
            }
        }
        
        String expected = "Where are you? You are late! I have asked you to be on time.";
        assertEquals(expected, longestMessage, 
                "The system returns: " + expected);
    }

    @Test
    public void testSearchForMessageID() {
        String messageId = "0838884567";
        String result = Message.searchByMessageID(messageId);
        String expectedMessage = "It is dinner time!";
        
        assertTrue(result.contains(expectedMessage), 
                "The system returns: " + expectedMessage + " when searching for message ID " + messageId);
        
        assertEquals(true, result.contains(expectedMessage), 
                "Search result contains expected message for ID " + messageId);
    }

    @Test
    public void testSearchAllMessagesForParticularRecipient() {
        String recipient = "+27838884567";
        List<String> messages = Message.searchMessagesByRecipient(recipient);
        
        String expectedMessage1 = "Where are you? You are late! I have asked you to be on time.";
        String expectedMessage2 = "Ok, I am leaving without you.";
        
        boolean foundMessage1 = messages.contains(expectedMessage1);
        boolean foundMessage2 = messages.contains(expectedMessage2);
        
        assertTrue(foundMessage1, "Found message: " + expectedMessage1);
        assertTrue(foundMessage2, "Found message: " + expectedMessage2);
        
        assertEquals(2, messages.size(), "Expected 2 messages for recipient " + recipient);
        
        assertTrue(messages.contains(expectedMessage1) && messages.contains(expectedMessage2),
                "The system returns: \"" + expectedMessage1 + "\", \"" + expectedMessage2 + "\"");
    }

    @Test
    public void testDeleteMessageUsingMessageHash() {
        String messageHashToDelete = "";
        String expectedDeletedMessage = "Where are you? You are late! I have asked you to be on time.";
        
        for (Message m : Message.storedMessages) {
            if (m.getMessageText().equals(expectedDeletedMessage)) {
                messageHashToDelete = m.getMessageHash();
                break;
            }
        }
        
        assertFalse(messageHashToDelete.isEmpty(), "Found message hash for deletion test");
        
        String result = Message.deleteMessageByHash(messageHashToDelete);
        String expectedResult = "Message \"" + expectedDeletedMessage + "\" successfully deleted.";
        
        assertEquals(expectedResult, result, 
                "The system returns: " + expectedResult);
    }

    @Test
    public void testDisplayReport() {
        String report = Message.displaySentMessagesReport();
        
        assertTrue(report.contains("SENT MESSAGES REPORT"), "Report contains proper header");
        assertTrue(report.contains("Message Hash:"), "Report contains Message Hash field");
        assertTrue(report.contains("Recipient:"), "Report contains Recipient field");
        assertTrue(report.contains("Message:"), "Report contains Message field");

        assertTrue(report.contains("Did you get the cake?"), "Report contains test message 1");
        assertTrue(report.contains("It is dinner time!"), "Report contains test message 4");
        assertTrue(report.contains("+27834557896"), "Report contains recipient information");
        
        int sentMessageCount = Message.sentMessages.size();
        int reportMessageCount = report.split("Message Hash:").length - 1; 
        
        assertEquals(sentMessageCount, reportMessageCount, 
                "Report displays all " + sentMessageCount + " sent messages");
    }

    
    @Test
    public void testAllArraysProperlyPopulated() {
        assertEquals(2, Message.sentMessages.size(), "Sent messages array has 2 messages");
        
        assertEquals(1, Message.disregardedMessages.size(), "Disregarded messages array has 1 message");
        
        assertEquals(2, Message.storedMessages.size(), "Stored messages array has 2 messages");
        
        assertEquals(5, Message.messageHashes.size(), "Message hashes array has 5 hashes");
        
        assertEquals(5, Message.messageIDs.size(), "Message IDs array has 5 IDs");
        
        assertTrue(Message.disregardedMessages.get(0).getMessageText().equals("Yohoooo, I am at your gate."),
                "Disregarded message contains correct test data");
    }

    @Test
    public void testTestDataPlacementInArrays() {
        boolean foundMsg1InSent = Message.sentMessages.stream()
                .anyMatch(m -> m.getMessageText().equals("Did you get the cake?") && 
                             m.getRecipient().equals("+27834557896"));
        assertTrue(foundMsg1InSent, "Test Data Message 1 correctly placed in sent messages");
        
        boolean foundMsg2InStored = Message.storedMessages.stream()
                .anyMatch(m -> m.getMessageText().equals("Where are you? You are late! I have asked you to be on time.") && 
                             m.getRecipient().equals("+27838884567"));
        assertTrue(foundMsg2InStored, "Test Data Message 2 correctly placed in stored messages");
        
        boolean foundMsg3InDisregarded = Message.disregardedMessages.stream()
                .anyMatch(m -> m.getMessageText().equals("Yohoooo, I am at your gate.") && 
                             m.getRecipient().equals("+27834484567"));
        assertTrue(foundMsg3InDisregarded, "Test Data Message 3 correctly placed in disregarded messages");
        
        boolean foundMsg4InSent = Message.sentMessages.stream()
                .anyMatch(m -> m.getMessageText().equals("It is dinner time!") && 
                             m.getMessageID().equals("0838884567"));
        assertTrue(foundMsg4InSent, "Test Data Message 4 correctly placed in sent messages");
        
        boolean foundMsg5InStored = Message.storedMessages.stream()
                .anyMatch(m -> m.getMessageText().equals("Ok, I am leaving without you.") && 
                             m.getRecipient().equals("+27838884567"));
        assertTrue(foundMsg5InStored, "Test Data Message 5 correctly placed in stored messages");
    }
}