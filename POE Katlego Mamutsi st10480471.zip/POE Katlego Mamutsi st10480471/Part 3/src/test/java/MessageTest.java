import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class MessageTest {

    @BeforeEach
    public void setUp() {
        Message.populateTestData();
    }

    @Test
    public void testMessageLengthSuccess() {
        String msgText = "Hi Mike, can you join us for dinner tonight";
        assertTrue(msgText.length() <= 250, "Message ready to send.");
    }

    @Test
    public void testMessageLengthFailure() {
        String longMessage = "A".repeat(260);
        int overBy = longMessage.length() - 250;
        assertTrue(longMessage.length() > 250,
                "Message exceeds 250 characters by " + overBy + ", please reduce size.");
    }

    @Test
    public void testRecipientPhoneNumberSuccess() {
        Message m = new Message("1234567890", "+27718693002", "Hello");
        assertEquals(12, m.checkRecipientCell(), "Cell phone number successfully captured.");
    }

    @Test
    public void testRecipientPhoneNumberFailure() {
        Message m = new Message("1234567890", "08575975889", "Hello");
        assertEquals(-1, m.checkRecipientCell(), "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
    }

    @Test
    public void testMessageIDLength() {
        String id = "1234567890";
        Message m = new Message(id, "+27718693002", "Hello");
        assertTrue(m.checkMessageID(), "Message ID generated: " + m.getMessageID());
    }

    @Test
    public void testCreateMessageHash() {
        Message m = new Message("0034567890", "+27718693002", "Hi Mike, can you join us for dinner tonight");
        String expectedHash = "00:1:HITONIGHT";
        assertEquals(expectedHash, m.getMessageHash());
    }

    @Test
    public void testSendMessageOption() {
        Message m = new Message("1234567890", "+27718693002", "Hello Mike");
        String userChoice = "send";
        assertEquals("send", userChoice, "Message successfully sent.");
    }

    @Test
    public void testDisregardMessageOption() {
        Message m = new Message("1234567890", "+27718693002", "Hello Mike");
        String userChoice = "disregard";
        assertEquals("disregard", userChoice, "Message disregarded.");
    }

    @Test
    public void testStoreMessageOption() {
        Message m = new Message("1234567890", "+27718693002", "Hello Mike");
        String userChoice = "store";
        assertEquals("store", userChoice, "Message successfully stored.");
    }


    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        List<String> expectedMessages = List.of("Did you get the cake?", "It is dinner time!");
        
        boolean foundMessage1 = false;
        boolean foundMessage4 = false;
        
        for (Message m : Message.sentMessages) {
            if (m.getMessageText().equals("Did you get the cake?")) {
                foundMessage1 = true;
            }
            if (m.getMessageText().equals("It is dinner time!")) {
                foundMessage4 = true;
            }
        }
        
        assertTrue(foundMessage1 && foundMessage4, 
                "The Messages array contains the expected test data: " + expectedMessages);
    }

    @Test
    public void testDisplayLongestMessage() {
        String longest = Message.displayLongestSentMessage();
        
        String expected = "It is dinner time!"; 
        
        boolean containsExpectedLongest = longest.length() > 0;
        assertTrue(containsExpectedLongest, 
                "The system returns the longest message");
    }

    @Test
    public void testSearchForMessageID() {
        String result = Message.searchByMessageID("0838884567");
        String expected = "It is dinner time!";
        
        assertTrue(result.contains(expected), 
                "The system returns: " + expected + " for message ID 0838884567");
    }

    @Test
    public void testSearchAllMessagesForParticularRecipient() {
        List<String> messages = Message.searchMessagesByRecipient("+27838884567");
        
        boolean foundMessage2 = false;
        boolean foundMessage5 = false;
        
        for (String msg : messages) {
            if (msg.contains("Where are you? You are late!")) {
                foundMessage2 = true;
            }
            if (msg.equals("Ok, I am leaving without you.")) {
                foundMessage5 = true;
            }
        }
        
        assertTrue(foundMessage2 && foundMessage5, 
                "The system returns messages for recipient +27838884567: " + messages);
    }

    @Test
    public void testDeleteMessageUsingMessageHash() {
        String messageHashToDelete = "";
        for (Message m : Message.storedMessages) {
            if (m.getMessageText().contains("Where are you? You are late!")) {
                messageHashToDelete = m.getMessageHash();
                break;
            }
        }
        
        String result = Message.deleteMessageByHash(messageHashToDelete);
        String expected = "Where are you? You are late! I have asked you to be on time";
        
        assertTrue(result.contains("successfully deleted"), 
                "Message \"" + expected + "\" successfully deleted.");
    }

    @Test
    public void testDisplayReport() {
        String report = Message.displaySentMessagesReport();
        
        assertTrue(report.contains("Message Hash"), "Report contains Message Hash");
        assertTrue(report.contains("Recipient"), "Report contains Recipient");
        assertTrue(report.contains("Message"), "Report contains Message");
        assertTrue(report.contains("SENT MESSAGES REPORT"), "Report has proper header");
    }

    @Test
    public void testMessageArraysPopulation() {
        assertTrue(Message.sentMessages.size() >= 2, "Sent messages array populated");
        assertTrue(Message.storedMessages.size() >= 2, "Stored messages array populated");
        assertTrue(Message.disregardedMessages.size() >= 1, "Disregarded messages array populated");
        assertTrue(Message.messageHashes.size() >= 5, "Message hashes array populated");
        assertTrue(Message.messageIDs.size() >= 5, "Message IDs array populated");
    }

    @Test
    public void testSpecificTestDataMessages() {
        boolean foundCakeMessage = false;
        boolean foundDinnerMessage = false;
        boolean foundLateMessage = false;
        boolean foundGateMessage = false;
        boolean foundLeavingMessage = false;

        for (Message m : Message.sentMessages) {
            if (m.getMessageText().equals("Did you get the cake?")) foundCakeMessage = true;
            if (m.getMessageText().equals("It is dinner time!")) foundDinnerMessage = true;
        }

        for (Message m : Message.storedMessages) {
            if (m.getMessageText().contains("Where are you? You are late!")) foundLateMessage = true;
            if (m.getMessageText().equals("Ok, I am leaving without you.")) foundLeavingMessage = true;
        }

        for (Message m : Message.disregardedMessages) {
            if (m.getMessageText().equals("Yohoooo, I am at your gate.")) foundGateMessage = true;
        }

        assertTrue(foundCakeMessage, "Test message 1 found in sent messages");
        assertTrue(foundDinnerMessage, "Test message 4 found in sent messages");
        assertTrue(foundLateMessage, "Test message 2 found in stored messages");
        assertTrue(foundLeavingMessage, "Test message 5 found in stored messages");
        assertTrue(foundGateMessage, "Test message 3 found in disregarded messages");
    }
}