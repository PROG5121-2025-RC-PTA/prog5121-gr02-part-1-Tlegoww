import javax.swing.*;
import java.util.*;

public class Chat {
    private final Login user;
    private final Map<String, Login> users;
    private final Map<String, List<String>> inbox = new HashMap<>();

    public Chat(Login user, Map<String, Login> users) {
        this.user = user;
        this.users = users;
        for (String u : users.keySet()) {
            inbox.putIfAbsent(u, new ArrayList<>());
        }
    }

    public void run() {
        while (true) {
            String[] options = {"Send Message", "View Inbox", "Logout"};
            int choice = JOptionPane.showOptionDialog(
                    null,
                    "Logged in as: " + user.getUsername(),
                    "--- Chat Interface ---",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            switch (choice) {
                case 0 -> sendMessage();
                case 1 -> viewMessages();
                case 2 -> {
                    JOptionPane.showMessageDialog(null, "Logging out...");
                    return;
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }

    private void sendMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient username:");
        if (recipient == null || !users.containsKey(recipient)) {
            JOptionPane.showMessageDialog(null, "User not found.");
            return;
        }

        String msg = JOptionPane.showInputDialog("Enter message:");
        if (msg == null) return;

        inbox.get(recipient).add("From " + user.getUsername() + ": " + msg);
        JOptionPane.showMessageDialog(null, "Message sent to " + recipient + "!");
    }

    private void viewMessages() {
        List<String> myMessages = inbox.get(user.getUsername());

        if (myMessages == null || myMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages yet.");
        } else {
            StringBuilder messageList = new StringBuilder();
            for (String message : myMessages) {
                messageList.append(message).append("\n");
            }
            JOptionPane.showMessageDialog(null, messageList.toString(), "Inbox", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
