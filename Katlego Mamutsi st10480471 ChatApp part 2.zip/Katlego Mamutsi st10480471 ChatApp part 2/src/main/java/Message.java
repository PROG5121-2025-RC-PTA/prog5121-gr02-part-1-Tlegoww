import javax.swing.*;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.parser.ParseException;

public class Message {
    private final String messageID;
    private final int messageNumber;
    private final String recipient;    
    private final String messageText;  
    private final String messageHash;  

    
    public static int counter = 0;
    public static List<Message> sentMessages = new ArrayList<>();

    public Message(String messageID, String recipient, String messageText) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = ++counter;
        this.messageHash = createMessageHash();
    }

   
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    
    public int checkRecipientCell() {
        if (recipient != null && recipient.startsWith("+27") && recipient.length() == 12) {
            return recipient.length();
        } else {
            return -1;
        }
    }

    
    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = "";
        String lastWord = "";
        if (words.length > 0) {
            firstWord = words[0];
            lastWord = words[words.length - 1];
        }
        String hash = firstTwo + ":" + messageNumber + ":" + (firstWord + lastWord);
        return hash.toUpperCase();
    }

    public String SentMessage() {
        String[] options = {"Send message", "Disregard message", "Store message to send later"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "Choose an action for the message:",
                "Message Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]
        );
        return switch (choice) {
            case 0 -> "send";
            case 1 -> "disregard";
            case 2 -> "store";
            default -> "disregard";
        };
    }

    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("MessageID: ").append(m.messageID).append("\n")
              .append("Message Hash: ").append(m.messageHash).append("\n")
              .append("Recipient: ").append(m.recipient).append("\n")
              .append("Message: ").append(m.messageText).append("\n\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return sentMessages.size();
    }

    public void storeMessage() {
        JSONObject messageObj = new JSONObject();
        messageObj.put("messageID", messageID);
        messageObj.put("messageNumber", messageNumber);
        messageObj.put("messageHash", messageHash);
        messageObj.put("recipient", recipient);
        messageObj.put("messageText", messageText);

        JSONArray messageList = new JSONArray();

        try {
            JSONParser parser = new JSONParser();
            try (FileReader reader = new FileReader("stored_messages.json")) {
                Object obj = parser.parse(reader);
                messageList = (JSONArray) obj;
            }
        } catch (IOException | ParseException e) {           
        }

        messageList.add(messageObj);

        try (FileWriter file = new FileWriter("stored_messages.json")) {
            file.write(messageList.toJSONString());
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving message: " + e.getMessage());
        }
    }
    
    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }
}
