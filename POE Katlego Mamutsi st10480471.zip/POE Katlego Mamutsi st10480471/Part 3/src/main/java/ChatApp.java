import javax.swing.*;
import java.util.*;

public class ChatApp {
    static Map<String, Login> users = new HashMap<>();
    static Login currentUser;

    public static void main(String[] args) {
        try {
            System.out.println("Starting ChatApp...");
            JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
            
            
            initializeTestUsers();
            System.out.println("Test users initialized successfully.");

            while (true) {
                try {
                    String[] options = {"Register", "Login", "Exit"};
                    int choice = JOptionPane.showOptionDialog(
                            null, "==== ChatApp Menu ====",
                            "ChatApp",
                            JOptionPane.DEFAULT_OPTION,
                            JOptionPane.INFORMATION_MESSAGE,
                            null,
                            options,
                            options[0]);

                    System.out.println("User selected main menu option: " + choice);

                    switch (choice) {
                        case 0 -> {
                            System.out.println("Executing: Register");
                            register();
                        }
                        case 1 -> {
                            System.out.println("Executing: Login");
                            login();
                        }
                        case 2, -1 -> { 
                            System.out.println("Executing: Exit");
                            JOptionPane.showMessageDialog(null, "Goodbye!");
                            System.exit(0);
                        }
                        default -> {
                            System.out.println("Invalid option selected: " + choice);
                            JOptionPane.showMessageDialog(null, "Invalid option.");
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Error in main menu loop: " + e.getMessage());
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "An error occurred in the main menu: " + e.getMessage());
                }
            }
        } catch (Exception e) {
            System.err.println("Fatal error in main method: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Fatal error: " + e.getMessage());
        }
    }

    private static void initializeTestUsers() {
        try {
            
            Login testUser1 = new Login("test_", "Password1!", "+27834557896", "John", "Doe");
            Login testUser2 = new Login("user_", "SecurePass2@", "+27838884567", "Jane", "Smith");
            Login testUser3 = new Login("demo_", "Demo123#", "+27834484567", "Demo", "User");
            
            users.put("test_", testUser1);
            users.put("user_", testUser2);
            users.put("demo_", testUser3);
            
            System.out.println("Test users added: test_, user_, demo_");
        } catch (Exception e) {
            System.err.println("Error initializing test users: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void register() {
        try {
            String username = JOptionPane.showInputDialog("Enter Username:");
            if (username == null) return;

            if (users.containsKey(username)) {
                JOptionPane.showMessageDialog(null, "Username already taken. Please choose another.");
                return;
            }

            String password = JOptionPane.showInputDialog("Enter Password:");
            if (password == null) return;

            String cell = JOptionPane.showInputDialog("Enter Cell Phone (+27 format):");
            if (cell == null) return;

            String first = JOptionPane.showInputDialog("Enter First Name:");
            if (first == null) return;

            String last = JOptionPane.showInputDialog("Enter Last Name:");
            if (last == null) return;

            Login newUser = new Login(username, password, cell, first, last);
            String msg = newUser.registerUser();
            JOptionPane.showMessageDialog(null, msg);

            if (msg.equals("User registered successfully!")) {
                users.put(username, newUser);
                System.out.println("User registered successfully: " + username);
            }
        } catch (Exception e) {
            System.err.println("Error in register method: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error during registration: " + e.getMessage());
        }
    }

    private static void login() {
        try {
            String user = JOptionPane.showInputDialog("Enter Username:");
            if (user == null) return;

            String pass = JOptionPane.showInputDialog("Enter Password:");
            if (pass == null) return;

            Login loginUser = users.get(user);
            if (loginUser == null) {
                JOptionPane.showMessageDialog(null, "No such user. Please register first.");
                return;
            }

            System.out.println("Attempting login for user: " + user);

            if (loginUser.loginUser(user, pass)) {
                currentUser = loginUser;
                System.out.println("Login successful for user: " + user);
                JOptionPane.showMessageDialog(null, currentUser.returnLoginStatus());
                startChat();
            } else {
                System.out.println("Login failed for user: " + user);
                JOptionPane.showMessageDialog(null, loginUser.returnLoginStatus());
            }
        } catch (Exception e) {
            System.err.println("Error in login method: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error during login: " + e.getMessage());
        }
    }

    private static void startChat() {
        try {
            System.out.println("Starting chat for user: " + currentUser.getFirstName());
            Chat chat = new Chat(currentUser, users);
            System.out.println("Chat object created successfully, calling run()...");
            chat.run();
            System.out.println("Chat run() method completed.");
        } catch (Exception e) {
            System.err.println("Error in startChat method: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error starting chat: " + e.getMessage());
        }
    }
}