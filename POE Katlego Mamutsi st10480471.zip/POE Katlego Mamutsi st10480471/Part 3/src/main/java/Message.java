import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Message {
    private final String messageID;
    private final int messageNumber;
    private final String recipient;    
    private final String messageText;  
    private final String messageHash;
    private final String sender;  

    public static int counter = 0;
    public static List<Message> sentMessages = new ArrayList<>();
    public static List<Message> disregardedMessages = new ArrayList<>();
    public static List<Message> storedMessages = new ArrayList<>();
    public static List<String> messageHashes = new ArrayList<>();
    public static List<String> messageIDs = new ArrayList<>();

    public Message(String messageID, String recipient, String messageText) {
        this(messageID, recipient, messageText, "Current User"); 
    }

    public Message(String messageID, String recipient, String messageText, String sender) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.messageText = messageText;
        this.sender = sender;
        this.messageNumber = ++counter;
        this.messageHash = createMessageHash();
        
        
        messageHashes.add(this.messageHash);
        messageIDs.add(this.messageID);
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public int checkRecipientCell() {
        if (recipient != null && recipient.startsWith("+27") && recipient.length() == 12) {
            return recipient.length();
        } else {
            return -1;
        }
    }

    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = "";
        String lastWord = "";
        if (words.length > 0) {
            firstWord = words[0];
            lastWord = words[words.length - 1];
        }
        String hash = firstTwo + ":" + messageNumber + ":" + (firstWord + lastWord);
        return hash.toUpperCase();
    }

    public String SentMessage() {
        String[] options = {"Send message", "Disregard message", "Store message to send later"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "Choose an action for the message:",
                "Message Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]
        );
        return switch (choice) {
            case 0 -> "send";
            case 1 -> "disregard";
            case 2 -> "store";
            default -> "disregard";
        };
    }

    
    public static void populateTestData() {
        
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
        counter = 0;

        
        Message msg1 = new Message("1234567890", "+27834557896", "Did you get the cake?", "Current User");
        sentMessages.add(msg1);

        
        Message msg2 = new Message("2345678901", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Current User");
        storedMessages.add(msg2);

        
        Message msg3 = new Message("3456789012", "+27834484567", "Yohoooo, I am at your gate.", "Current User");
        disregardedMessages.add(msg3);

        
        Message msg4 = new Message("0838884567", "+27834557896", "It is dinner time!", "Current User");
        sentMessages.add(msg4);

        
        Message msg5 = new Message("4567890123", "+27838884567", "Ok, I am leaving without you.", "Current User");
        storedMessages.add(msg5);
    }

    
    public static void loadStoredMessagesFromJSON() {
        try {
            System.out.println("Loading stored messages...");
        } catch (Exception e) {
            System.out.println("Error loading stored messages: " + e.getMessage());
        }
    }

    
    public static String displaySenderRecipientSentMessages() {
        StringBuilder sb = new StringBuilder("Sent Messages - Sender and Recipient:\n");
        for (Message m : sentMessages) {
            sb.append("Sender: ").append(m.sender)
              .append(", Recipient: ").append(m.recipient).append("\n");
        }
        return sb.toString();
    }

    
    public static String displayLongestSentMessage() {
        String longest = "";
        for (Message m : sentMessages) {
            if (m.messageText.length() > longest.length()) {
                longest = m.messageText;
            }
        }
        return longest;
    }

    
    public static String searchByMessageID(String messageID) {
        for (Message m : sentMessages) {
            if (m.messageID.equals(messageID)) {
                return "Recipient: " + m.recipient + ", Message: " + m.messageText;
            }
        }
        for (Message m : storedMessages) {
            if (m.messageID.equals(messageID)) {
                return "Recipient: " + m.recipient + ", Message: " + m.messageText;
            }
        }
        for (Message m : disregardedMessages) {
            if (m.messageID.equals(messageID)) {
                return "Recipient: " + m.recipient + ", Message: " + m.messageText;
            }
        }
        return "Message ID not found.";
    }

    
    public static List<String> searchMessagesByRecipient(String recipient) {
        List<String> messages = new ArrayList<>();
        
        
        for (Message m : sentMessages) {
            if (m.recipient.equals(recipient)) {
                messages.add(m.messageText);
            }
        }
        
        
        for (Message m : storedMessages) {
            if (m.recipient.equals(recipient)) {
                messages.add(m.messageText);
            }
        }
        
        return messages;
    }

    
    public static String deleteMessageByHash(String messageHash) {
        
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentMessages.get(i).messageHash.equals(messageHash)) {
                String deletedMessage = sentMessages.get(i).messageText;
                sentMessages.remove(i);
                messageHashes.remove(messageHash);
                return "Message \"" + deletedMessage + "\" successfully deleted.";
            }
        }
        
        
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).messageHash.equals(messageHash)) {
                String deletedMessage = storedMessages.get(i).messageText;
                storedMessages.remove(i);
                messageHashes.remove(messageHash);
                return "Message \"" + deletedMessage + "\" successfully deleted.";
            }
        }
        
        
        for (int i = 0; i < disregardedMessages.size(); i++) {
            if (disregardedMessages.get(i).messageHash.equals(messageHash)) {
                String deletedMessage = disregardedMessages.get(i).messageText;
                disregardedMessages.remove(i);
                messageHashes.remove(messageHash);
                return "Message \"" + deletedMessage + "\" successfully deleted.";
            }
        }
        
        return "Message hash not found.";
    }

    
    public static String displaySentMessagesReport() {
        StringBuilder sb = new StringBuilder("=== SENT MESSAGES REPORT ===\n");
        for (Message m : sentMessages) {
            sb.append("Message Hash: ").append(m.messageHash).append("\n")
              .append("Recipient: ").append(m.recipient).append("\n")
              .append("Message: ").append(m.messageText).append("\n")
              .append("Sender: ").append(m.sender).append("\n")
              .append("Message ID: ").append(m.messageID).append("\n")
              .append("----------------------------\n");
        }
        return sb.toString();
    }

    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("MessageID: ").append(m.messageID).append("\n")
              .append("Message Hash: ").append(m.messageHash).append("\n")
              .append("Recipient: ").append(m.recipient).append("\n")
              .append("Message: ").append(m.messageText).append("\n\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return sentMessages.size();
    }

    
    public void storeMessage() {
        try {
            System.out.println("Message stored: " + this.messageText);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saving message: " + e.getMessage());
        }
    }
    
    
    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getSender() {
        return sender;
    }

    public int getMessageNumber() {
        return messageNumber;
    }
}