import javax.swing.*;
import java.util.*;

public class Chat {
    private final Map<String, Login> users;
    private final Login currentUser;
    private int messageLimit = 0;
    private int messagesSent = 0;

    public Chat(Login user, Map<String, Login> users) {
        this.currentUser = user;
        this.users = users;
        
        try {
            System.out.println("Initializing chat for user: " + user.getFirstName());
            Message.populateTestData();
            Message.loadStoredMessagesFromJSON();
            System.out.println("Chat initialization completed successfully.");
        } catch (Exception e) {
            System.err.println("Error during chat initialization: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error initializing chat: " + e.getMessage());
        }
    }

    public void run() {
        try {
            System.out.println("Starting chat application...");
            
            String limitStr = JOptionPane.showInputDialog("Enter the number of messages you wish to send:");
            if (limitStr != null && !limitStr.trim().isEmpty()) {
                try {
                    messageLimit = Integer.parseInt(limitStr.trim());
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid number. Setting limit to 0.");
                    messageLimit = 0;
                }
            } else {
                JOptionPane.showMessageDialog(null, "No input provided. Setting limit to 0.");
                messageLimit = 0;
            }

            System.out.println("Message limit set to: " + messageLimit);

            while (true) {
                try {
                    String menu = """
                              ===== QuickChat Menu =====
                              1) Send Messages
                              2) Show recently sent messages
                              3) Display sender and recipient of sent messages
                              4) Display longest sent message
                              5) Search for message by ID
                              6) Search messages by recipient
                              7) Delete message by hash
                              8) Display sent messages report
                              9) Quit
                              Enter your option (1-9):""";
                    
                    String option = JOptionPane.showInputDialog(menu);
                    if (option == null) {
                        System.out.println("User cancelled menu selection.");
                        continue;
                    }

                    System.out.println("User selected option: " + option);

                    switch(option.trim()) {
                        case "1" -> {
                            System.out.println("Executing: Send Messages");
                            sendMessage();
                        }
                        case "2" -> {
                            System.out.println("Executing: Show recently sent messages");
                            String allMessages = Message.printMessages();
                            if (allMessages.isEmpty()) {
                                JOptionPane.showMessageDialog(null, "No messages have been sent yet.");
                            } else {
                                JOptionPane.showMessageDialog(null, allMessages);
                            }
                        }
                        case "3" -> {
                            System.out.println("Executing: Display sender and recipient");
                            String senderRecipient = Message.displaySenderRecipientSentMessages();
                            JOptionPane.showMessageDialog(null, senderRecipient);
                        }
                        case "4" -> {
                            System.out.println("Executing: Display longest sent message");
                            String longestMessage = Message.displayLongestSentMessage();
                            if (longestMessage.isEmpty()) {
                                JOptionPane.showMessageDialog(null, "No sent messages found.");
                            } else {
                                JOptionPane.showMessageDialog(null, "Longest message: " + longestMessage);
                            }
                        }
                        case "5" -> {
                            System.out.println("Executing: Search for message by ID");
                            String searchID = JOptionPane.showInputDialog("Enter message ID to search:");
                            if (searchID != null) {
                                String result = Message.searchByMessageID(searchID);
                                JOptionPane.showMessageDialog(null, result);
                            }
                        }
                        case "6" -> {
                            System.out.println("Executing: Search messages by recipient");
                            String searchRecipient = JOptionPane.showInputDialog("Enter recipient to search for:");
                            if (searchRecipient != null) {
                                List<String> messages = Message.searchMessagesByRecipient(searchRecipient);
                                if (messages.isEmpty()) {
                                    JOptionPane.showMessageDialog(null, "No messages found for recipient: " + searchRecipient);
                                } else {
                                    StringBuilder sb = new StringBuilder("Messages for " + searchRecipient + ":\n");
                                    for (String msg : messages) {
                                        sb.append("- ").append(msg).append("\n");
                                    }
                                    JOptionPane.showMessageDialog(null, sb.toString());
                                }
                            }
                        }
                        case "7" -> {
                            System.out.println("Executing: Delete message by hash");
                            String hashToDelete = JOptionPane.showInputDialog("Enter message hash to delete:");
                            if (hashToDelete != null) {
                                String result = Message.deleteMessageByHash(hashToDelete);
                                JOptionPane.showMessageDialog(null, result);
                            }
                        }
                        case "8" -> {
                            System.out.println("Executing: Display sent messages report");
                            String report = Message.displaySentMessagesReport();
                            JOptionPane.showMessageDialog(null, report);
                        }
                        case "9" -> {
                            System.out.println("Executing: Quit");
                            String total = "Total number of messages sent: " + Message.returnTotalMessages();
                            JOptionPane.showMessageDialog(null, total);
                            System.out.println("Chat application ended.");
                            return;
                        }
                        default -> {
                            System.out.println("Invalid option selected: " + option);
                            JOptionPane.showMessageDialog(null, "Invalid option. Please select 1-9.");
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Error in menu loop: " + e.getMessage());
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage());
                }
            }
        } catch (Exception e) {
            System.err.println("Fatal error in chat run method: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Fatal error: " + e.getMessage());
        }
    }

    private void sendMessage() {
    if (messagesSent >= messageLimit) {
        JOptionPane.showMessageDialog(null, "Message limit reached. You cannot send more messages.");
        return;
    }

    String recipientCell = JOptionPane.showInputDialog("Enter recipient cell number (e.g.  +27662411540):");
    if (recipientCell == null || !recipientCell.matches("^\\+27\\d{9}$")) {
        JOptionPane.showMessageDialog(null, "Invalid recipient cell number format. It must start with +27 and have 12 digits total.");
        return;
    }

    Login recipientLogin = null;
    for (Login user : users.values()) {
        if (user.getCellPhone().equals(recipientCell)) {
            recipientLogin = user;
            break;
        }
    }

    if (recipientLogin == null) {
        JOptionPane.showMessageDialog(null, "No user registered with this cell number.");
        return;
    }

    String messageText = JOptionPane.showInputDialog("Enter message (max 50 characters):");
    if (messageText == null) return;
    if (messageText.length() >= 50) {
        JOptionPane.showMessageDialog(null, "Please enter a message of less than 50 characters.");
        return;
    }

    long idLong = Math.abs(new java.util.Random().nextLong()) % 10000000000L;
    String messageID = String.format("%010d", idLong);

    Message msg = new Message(messageID, recipientCell, messageText);

    if (!msg.checkMessageID()) {
        JOptionPane.showMessageDialog(null, "Invalid Message ID generated.");
        return;
    }
    if (msg.checkRecipientCell() == -1) {
        JOptionPane.showMessageDialog(null, "Invalid recipient cell number.");
        return;
    }

    String action = msg.SentMessage();
    switch (action) {
        case "send" -> {
            Message.sentMessages.add(msg);
            messagesSent++;
            JOptionPane.showMessageDialog(null,
                    """
                    Message sent!

                    MessageID: """ + msg.getMessageID() + "\n" +
                                    "Message Hash: " + msg.getMessageHash() + "\n" +
                                            "Recipient: " + msg.getRecipient() + "\n" +
                                                    "Message: " + msg.getMessageText());
        }
        case "store" -> {
            msg.storeMessage();
            Message.sentMessages.add(msg);
            messagesSent++;
            JOptionPane.showMessageDialog(null,
                    """
                    Message stored to send later!

                    MessageID: """ + msg.getMessageID() + "\n" +
                                    "Message Hash: " + msg.getMessageHash() + "\n" +
                                            "Recipient: " + msg.getRecipient() + "\n" +
                                                    "Message: " + msg.getMessageText());
        }
        case "disregard" -> JOptionPane.showMessageDialog(null, "Message disregarded.");
        default -> {}
    }
}
}
